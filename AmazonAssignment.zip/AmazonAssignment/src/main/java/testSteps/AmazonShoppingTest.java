package testSteps;

import java.time.Duration;
import java.util.ArrayList;
import java.util.Set;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.Assert;
import org.testng.annotations.*;
import org.testng.annotations.Parameters;

import io.github.bonigarcia.wdm.WebDriverManager;
import pageObjects.AmazonApplePage;
import pageObjects.AmazonHomePage;
import pageObjects.AmazonProductPage;
import pageObjects.AmazonResultPage;
import utilities.AbstractUtility;

public class AmazonShoppingTest  {
	
	protected WebDriver driver;
	
	AmazonHomePage ap;
	AmazonResultPage ElectronicResult;
	AmazonProductPage product;
	AmazonApplePage ApplePAge;
	
	public AmazonShoppingTest() {
		
	}


	@Parameters({"Url"})
	@BeforeTest
	public void LaunchApplication(String Url) throws InterruptedException
	{
		ChromeOptions chromeOptions = new ChromeOptions();
		chromeOptions.addArguments("--disable-search-engine-choice-screen");
		chromeOptions.addArguments("user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36");
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver(chromeOptions);
		
		//System.setProperty("webdriver.chrome.driver",System.getProperty("User.dir")+"//Driver/chromedriver.exe");
		//System.setProperty("webdriver.chrome.driver","C:/Users/tasmi/eclipse-workspace/TestNGFramework/Drivers/chromedriver.exe");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		driver.get("https://www.amazon.in/");
		driver.manage().window().maximize();
		Thread.sleep(5000);
	}
	
	@Parameters({"Electronics"})
	@Test(priority=1)
	public void ValidateElectronicAapp(String electronic)
	{
		ap = new AmazonHomePage(driver);
		//Click on Electronics from dropdown menu and type �IPhone 13�
		ap.selectValueByText("Electronics");
		ap.SearchElectronics(electronic);
		//Get All the dropdown suggestions and validate all are related to searched product
		boolean exp =ap.validateListOfTexts(electronic);
		Assert.assertTrue(exp);
		
		//String confirmMessage = confirmationPage.getConfirmationMessage();
		//Assert.assertTrue(confirmMessage.equalsIgnoreCase(string));
		
	}
	//AmazonResultPage 
	
	@Parameters({"FinalElectronics"})
	@Test(priority=2)
	public void SelectElectronicValidateNewTab(String iphone)
	{
		ElectronicResult = new AmazonResultPage(driver);
		//Then Type again �IPhone 13 128 GB� variant and Click �iPhone 13 128GB� variant from dropdown Result.
		ElectronicResult.selectFirstProduct();
		
		//From Results, click on the searched product and validate new tab is opened

		// Store the current window handle
        String mainTab = driver.getWindowHandle();

        // Get all window handles
        Set<String> windowHandles = driver.getWindowHandles();

        // Validate that a new tab is opened
        if (windowHandles.size() > 1) {
            System.out.println("Validation Passed: A new tab is opened.");
        } else {
            throw new RuntimeException("Validation Failed: No new tab is opened.");
        }

        // Convert the Set to a List to access handles by index
        ArrayList<String> tabs = new ArrayList<>(windowHandles);

        // Switch to the new tab
        for (String handle : tabs) {
            if (!handle.equals(mainTab)) {
                driver.switchTo().window(handle);
                break;
            }
        }

        // Validate the new tab content (example: check the title)
        String newTabTitle = driver.getTitle();
        System.out.println("New Tab Title: " + newTabTitle);

        //driver.switchTo().window(mainTab);

	}
	
	
	
	
	@Test(priority=3)
	public void SelectVisitStore()
	{
		product = new AmazonProductPage(driver);
		//Navigate to next tab and click on Visit the Apple Store link appears below Apple 
		//iPhone 13 (128 GB) variant
		product.selectVisitStore();
		
	}
	
	
	
	@Parameters({"Watch"})
	@Test(priority=4)
	public void SelectApple(String Watch)
	{
		ApplePAge = new AmazonApplePage(driver);
		//Click on Apple Watch dropdown and select Apple Watch SE (GPS + Cellular)

		ApplePAge.selectAppleDropdown();
		
		ApplePAge.inputField(Watch).click();
		
		
	}
	
	
	@Test(priority=5)
	public void VerifyQuickLook()
	{
		AmazonApplePage ApplePAge1 = new AmazonApplePage(driver);
		//Hover on watch image and verify Quick Look is displayed for the watch.
		ApplePAge1.selectQuickLook();
		//Verify newly opened modal is related to Same product for which Quick look is performed
		ApplePAge1.verifyQuickResult();
	}
	
	@AfterTest
	public void CloseApplication()
	{
		driver.close();
		
		boolean verifydriverClosed = driver.getWindowHandles().isEmpty();
		
		Assert.assertTrue(verifydriverClosed);
		
	}
	
	
	
}
