package pageObjects;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import utilities.AbstractUtility;

public class AmazonProductPage extends AbstractUtility{

	WebDriver driver;
	
	public AmazonProductPage (WebDriver driver) 
	{
		super(driver);
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	
	@FindBy(xpath="//a[contains(text(),'Visit the Apple Store')]")
	private WebElement SelectVisit;
	
	
	
	public void selectVisitStore() {
		WaitForElementVisibility(SelectVisit);
		SelectVisit.click();
    }
	
	
}
