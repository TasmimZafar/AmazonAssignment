package pageObjects;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import utilities.AbstractUtility;

public class AmazonApplePage extends AbstractUtility{

	WebDriver driver;
	
	public AmazonApplePage (WebDriver driver) 
	{
		super(driver);
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath="//ul[@class='Navigation__navList__HrEra']/li[6]/a[1]")
	private WebElement SelectApple;
	
	
	public WebElement inputField(String name) {
		return driver.findElement(By.xpath("//span[contains(text(),'"+name+"')]"));
	      // return this.driver.findElement(String.format(By.xpath("//input[@name = '" + name + "']");
	    }
	
	
	@FindBy(xpath="//div[@id='4k2av5ugzs']//span[@class='QuickLook__label__tOBqR'][normalize-space()='Quick look']")
	private WebElement QuickLook;
	
	
	@FindBy(xpath="//a[contains(text(),'Apple Watch SE')]")
	private WebElement ExpectedQuickLookResult;
	
	@FindBy(xpath="//h3[contains(text(),'Apple Watch SE - Starlight Aluminium Case (GPS + Cellular, 40mm)')]")
	private WebElement ActualQuickLookResult;
	
	//Apple Watch SE (2nd Gen, 2023) [GPS + Cellular 40mm] Smartwatch with Starlight Aluminum Case with
	
	
	public void selectQuickLook() {
	 Actions actions = new Actions(driver);
     actions.moveToElement(QuickLook).perform();
     Assert.assertTrue(QuickLook.isDisplayed(), "'Quick Look' is not displayed!");
	}
	
	
	
	 //String actualText = "Apple iPhone 13";
     //String expectedStart = "Apple";

     // Assert that the actualText starts with the expected value
    
	public void verifyQuickResult() {
	
		// Assert.assertEquals(ExpectedQuickLookResult, ActualQuickLookResult);
		//Assert.assertTrue("Text does not start with the expected value.", ActualQuickLookResult.startsWith(ExpectedQuickLookResult));
		//assertThat("Text does not start with the expected value", ActualQuickLookResult, startsWith(ExpectedQuickLookResult));
		//Assert.assertTrue("Text does not start with the expected value.",ActualQuickLookResult.s
		
		try
		{
			if(ActualQuickLookResult.getText().startsWith(ExpectedQuickLookResult.getText()));
			
		}
		catch(Exception e)
		{
			System.out.println("Exception caught "+e.getMessage());
		}
		
		}
	
	//Apple Watch SE (GPS + Cellular)
	public void selectAppleDropdown() {
		WaitForElementVisibility(SelectApple);
		SelectApple.click();
    }
	
	
	
	
	
	
}
