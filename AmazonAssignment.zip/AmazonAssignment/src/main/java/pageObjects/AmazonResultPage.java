package pageObjects;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import utilities.AbstractUtility;

public class AmazonResultPage extends AbstractUtility{

	WebDriver driver;
	
	public AmazonResultPage (WebDriver driver) 
	{
		super(driver);
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	
	@FindBy(xpath="//span[contains(text(),'Apple iPhone 13 (128GB)')]")
	private List<WebElement> SelectSearchedItem;
	
	public WebElement getFirstProductElement() {
        if (!SelectSearchedItem.isEmpty()) {
            return SelectSearchedItem.get(0);
        }
        throw new RuntimeException("No product elements found!");
    }
	
	public void selectFirstProduct() {
		//getFirstProductElement.Click();
		
		getFirstProductElement().click();
    }
	
	
}
