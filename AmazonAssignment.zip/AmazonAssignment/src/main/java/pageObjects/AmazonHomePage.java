package pageObjects;

import java.util.List;
import java.util.stream.Collectors;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import utilities.AbstractUtility;

public class AmazonHomePage extends AbstractUtility{

	WebDriver driver;
	
	public AmazonHomePage (WebDriver driver) 
	{
		super(driver);
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	//@FindBy(xpath="//Select[@title='Search in']")
	//List<WebElement> SelectElectronics;
	
	@FindBy(xpath="//Select[@title='Search in']")
	private WebElement SelectElectronics;

	@FindBy(xpath="//input[@placeholder='Search Amazon.in']")
	private WebElement SearchAmazon;

	@FindBy(xpath="//div[@id='sac-suggestion-row-1']//div[contains(text(),'iphone 13')]")
	private WebElement SelectFirst;
	
	
	@FindBy(xpath = "//div[@class='left-pane-results-container']//div[starts-with(@id,'sac-suggestion-row') and @role='row']")
    private List<WebElement> ElectronicsElementsList;

	public int getElementCount() {
        return ElectronicsElementsList.size();
    }
	
	public List<String> getElementTexts() {
        return ElectronicsElementsList.stream().map(WebElement::getText).collect(Collectors.toList());
    }
	
	public boolean validateListOfTexts(String expectedTexts) {
        return getElementTexts().equals(expectedTexts);
    }
	
	public void selectElectronic(String productName) {
		Actions a = new Actions(driver);
		a.sendKeys(SearchAmazon, productName).build().perform();
		WaitForElementVisibility(SelectFirst);
		SelectFirst.click();
	}
	
	public void selectValueByText(String text) {
        Select select = new Select(SelectElectronics);
        select.selectByVisibleText(text);
    }
	
	public void SearchElectronics(String text) {
		
		try
		{
			SearchAmazon.sendKeys(text);
		}
		catch(Exception e)
		{
			System.out.println("Exception caught "+e.getMessage());
		}
       
    }
	
	
	
	
	
	/*public Boolean ValidateElectronicAapp(String productName) {
		Boolean match = SelectElectronics.stream().anyMatch(product -> product.getText().startsWith(productName));
		return match;
		
	}*/
	
	}
	