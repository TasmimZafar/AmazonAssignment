package utilities;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class AbstractUtility {

	WebDriver driver;
	WebDriverWait wait;
	public AbstractUtility(WebDriver driver)
	{
		wait= new WebDriverWait(driver,Duration.ofSeconds(5));
		this.driver= driver;
	}
	public void WaitForElementToAppear(By FindBy)
	{
		wait.until(ExpectedConditions.presenceOfElementLocated(FindBy));
	}
	public void WaitForElementVisibility(WebElement selectFirst)
	{
		wait.until(ExpectedConditions.visibilityOfElementLocated((By) selectFirst));
	}
	public void WaitforAlertPresence(By FindBy)
	{
		wait.until(ExpectedConditions.alertIsPresent());
	}
	
}
